/**
 * Created by Vijaya Yeruva on 4/28/2017.
 */

    var MongoClient = require('mongodb').MongoClient;
    var url = 'mongodb://VIJAYAYERUVA:VIJAYAYERUVA@ds123361.mlab.com:23361/restapi';

    MongoClient.connect(url, function(err, db) {
        var cursor = db.collection('Sentiment').find();
        cursor.each(function(err,result){
            if(result != null)
            {
                console.log("Text:" + result.text);
                console.log("Sentiment:" + result.Sentiment);
            }
        });
    });
var test = function () {
};
